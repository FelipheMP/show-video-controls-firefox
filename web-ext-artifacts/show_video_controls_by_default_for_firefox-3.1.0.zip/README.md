# Show Video Controls for Firefox [![Ask DeepWiki](https://deepwiki.com/badge.svg)](https://deepwiki.com/FelipheMP/show-video-controls-firefox)
Firefox add-on that automatically enables video controls when playing html webm videos.

Useful when browsing meme sites such as 9gag.

No need to press the right mouse button and then "show controls".

They will appear by default for each media.

Keep in mind: This add-on may not/won't work in sites that use custom video players such as Instagram.

This is an UNOFFICIAL version for Firefox.  
Official Author: marcintracz.official
